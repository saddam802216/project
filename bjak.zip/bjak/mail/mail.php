<?php

require("class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "mail.domain.com";  /*SMTP server*/

$mail->SMTPAuth = true;
//$mail->SMTPSecure = "ssl";
$mail->Port = 587; // 465 587
$mail->Username = "saddam802216@gmail.com";  /*Username*/
$mail->Password = "";    /**Password**/

$mail->From = "saddam802216@gmail.com";    /*From address required*/
$mail->FromName = "Test from Info";
$mail->AddAddress("saddam802216@gmail.com");
$mail->AddReplyTo("saddam802216@gmail.com", "Saddam");

$mail->IsHTML(true);

$mail->Subject = "Test message from server";
$mail->Body = "Test Mail<b>in bold!</b>";
//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
echo "Message could not be sent. <p>";
echo "Mailer Error: " . $mail->ErrorInfo;
exit;
}

echo "Message has been sent";

?>