<?php
require('../connection.php');
$cars = array();
$filter = '';
if(isset($_GET['task']) && $_GET['task']=='delete'){
	$delID = ( isset($_GET['id']) && !empty($_GET['id']) )?$_GET['id']:0; 
	$sql = "DELETE FROM car WHERE id=".$delID;
	$conn->query($sql);
	header('Location: enquiry.php');
}
if(isset($_POST['filter']) && !empty($_POST['filter'])){
	//print_r($_POST['filter']); die();
	$filter = $_POST['filter'];
	if($_POST['filter']!='All'){
	//	$sql = "SELECT * FROM car ";
	    $myData = date('Y-m-d', strtotime('-7 days'));
	    $today = date('Y-m-d');
		$sql = "SELECT * FROM  car WHERE created >= DATEADD(DAY,-7,GETDATE())";
	}else{
		$sql = "SELECT * FROM car ";
	}
}else{
    $sql = "SELECT * FROM car ORDER BY id DESC";
}
// print_r($sql); die();
$result = $conn->query($sql);
if($result->num_rows > 0){
	while($car = $result->fetch_assoc()) {
		$cars[] = $car;			 
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Enquiry List</title>

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<style>
	.loader {
	  position: fixed;
	  top: 50%;
	  left: 50%;
	  z-index: 99;
	  display: none;
	  border: 16px solid #f3f3f3;
	  border-radius: 50%;
	  border-top: 16px solid blue;
	  border-right: 16px solid green;
	  border-bottom: 16px solid red;
	  border-left: 16px solid pink;
	  width: 120px;
	  height: 120px;
	  -webkit-animation: spin 2s linear infinite;
	  animation: spin 2s linear infinite;
	}

	@-webkit-keyframes spin {
	  0% { -webkit-transform: rotate(0deg); }
	  100% { -webkit-transform: rotate(360deg); }
	}

	@keyframes spin {
	  0% { transform: rotate(0deg); }
	  100% { transform: rotate(360deg); }
	}
	.new-btn{
		border: solid 1px #ddd;
		margin: 0px 10px;
		background-color: #4e73df;
		color: #fff;
	}
  </style>	
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
  
	 <?php require('sidebar.php'); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php require('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <div class="loader"></div>
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Enquiry Maintanance</h1>
          <!--<p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>-->

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <!--<div class="card-header py-3">-->
            <!--  <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>-->
            <!--</div>-->
            <div class="card-body">
              <div class="table-responsive">
			  
                  <div style="float:right"> 
    				<form id="filterForm" action="" method="POST">
    					<select name="filter" onChange="getFilterData()">
    					<option value="All" <?php echo ($filter=='All')?' selected ':''; ?>>All</option>
					<option value="Last" <?php echo ($filter=='Last')?' selected ':''; ?>>Last 30 days</option>
					<option value="After" <?php echo ($filter=='After')?' selected ':''; ?>>After 30 days</option>
    					</select>
    				</form>
    			  </div>
				  <div class="new" style="float:right" class="btn btn-default">
					<a class="new-btn btn btn-default" href="editenquiry.php" >+New</a>
				  </div>
				  
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>S No </th>	
                      <th>Name</th>
                      <th>IC</th>
                      <th>Phone</th>
                      <th>Email</th>
                      <th>Vehicle</th>
                      <th>Remark</th>
                      <th>Status</th>
					  <th>Edit</th>
					  <th>Delete</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>S No </th>	
                      <th>Name</th>
                      <th>IC</th>
                      <th>Phone</th>
                      <th>Email</th>
                      <th>Vehicle</th>
                      <th>Remark</th>
                      <th>Status</th>
					  <th>Edit</th>
					  <th>Delete</th>
                    </tr>
                  </tfoot>
                  <tbody>
				<?php
				$status = ['New', 'Quoted', 'Cancelled', 'Rejected', 'Paid', 'Shipped', 'Closed'];
				
				if(!count($cars)){
					echo "No record found";
				}else{
					$sno = 1;
					foreach($cars as $car){
						if(empty($car['name']) && empty($car['ic']) && empty($car['phone']) && empty($car['email']) && empty($car['vehicle']) && empty($car['remark']))
							continue;
							$htmlOption = '<select name="status" id="status_'.$car["id"].'" onChange="setStatus('.$car["id"].')"><option value="">Select Status </optoin>';
						foreach($status as $key=>$val){
							$selected = '';
							$selected = ($val == $car["status"]) ? "selected" : "";
							$htmlOption .= '<option '.$selected.' value="'.$val.'">'.$val.'</option>';
						}
						$htmlOption .= '</select>';
						
				?>
                    <tr>
					  <td><?php echo $sno; ?></td>
                      <td><?php echo $car['name']; ?></td>
                      <td><?php echo $car['ic']; ?></td>
                      <td><?php echo $car['phone']; ?></td>
                      <td><?php echo $car['email']; ?></td>
                      <td><?php echo $car['vehicle']; ?></td>
                      <td><?php echo $car['remark']; ?></td>
                      <td><?php echo $car['status']; ?></td>
					  <td><a href="editenquiry.php?id=<?php echo $car['id'] ?>"><?php echo '<i class="fas fa-edit"></i>'; ?></a></td>
					  <td><a href="enquiry.php?task=delete&id=<?php echo $car['id'] ?>"><?php echo '<i class="fas fa-trash"></i>' ?></a></td>
                    </tr>
				<?php 
					$sno++;
					} } 
				?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; jmat.my 2020</span>
            <div style="margin-top: 10px;">Developed By <a href="https://www.operion.com.my" target="_blank">Operion Web Creation Company</a></div>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
  
  <script>
  
	  function setStatus(id){ 
		var status = $('#status_'+id).val();
		jQuery.ajax({
			url: "ajax.php",
			type: "POST",
			dataType: "json",
			data: {
				"id": id,
				"status": status,
				"task":"statusUpdate"
			},

			beforeSend: function() {
				$('.loader').show();
				//jQuery(that).find("span.loadingbox").show();
			},

			complete: function() {
				$('.loader').hide();
				//jQuery(that).find("span.loadingbox").hide();
			},

			success: function(data) {
				console.log(data);
			}
		});
	  }
	  
	  function getFilterData(){
		  $('#filterForm').submit();
	  }
  
  </script>

</body>

</html>
