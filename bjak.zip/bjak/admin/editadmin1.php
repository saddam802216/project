<?php
require('../connection.php');
$id = 0;
if(isset($_GET['id']) && !empty($_GET['id'])){
	$id = $_GET['id'];	
}
if(!empty($id)){
	$sql = "SELECT * FROM users WHERE id=".$id;
	$result = $conn->query($sql);
	if($result->num_rows > 0){
		$enquiry = $result->fetch_assoc();
	}
}else{
	$enquiry = array(
		"id"=>null,
		"name"=>null,
		"email"=>null,Logout Modal
		"password"=>null
	);
}

if(isset($_POST['submit'])){
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  
  if(empty($id)){
	  // create new enquiry
	  $sql = "INSERT INTO `users` (id, name, user_type, username, password, email, phone)
	  VALUES (null, '".$name."', 'register', '', '".$password."', '".$email."', '')";
  }else{
	  // Update enquiry
	  $sql = "UPDATE users SET `name`='".$name."', `email`='".$email."', `password`='".$password."' WHERE id=".$id; 
  }
  if ($conn->query($sql) === TRUE) {
	  if(empty($id)){
        echo "<script>alert('User Created successfully');</script>";
		header('Location: admin.php');
	  }else{	
		echo "<script>alert('User Update successfully');</script>";  
	  }
  }
  
  //echo "<pre>"; print_r($conn->error); die();
  $conn->close();
  echo "<meta http-equiv='refresh' content='0'>";
  
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Add/Edit Enquiry</title>

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<style>
    .carousel-inner > .item > img,
    .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
    }
    .check-box-layout {
      display: inline-block;
      border: 1px solid #d6d6d6;
      border-radius: 3px;
      font-family: "Lato";
      font-size: 1.6rem;
      font-weight: 400;
      padding: 1.143rem;
      text-align: center;
      width: 48%;
    }
    .check-box-layout p{
      text-align: center;
      padding: 5px;
    }
    .check-right{
      float: right;
    }
    .button-full-width{
      width: 100%;
      padding: 15px;
      margin-top: 50px;
    }
    .button-green {
      background: #1db954;
      border: none;
      color: white;
      font-size: 2.24rem;
      font-weight: 900;
      height: auto;
      margin-top: 1.143rem;
      padding: 1.143rem 4.39rem;
      box-shadow: 3px 3px 2px rgba(102, 102, 102, 0.5);
      border-radius: 6px;
      font-family: "Lato";

    }
    .active{
      border: none;
      background-color: #290ce8;
      color: white;
      font-weight: 700;
    }
    .back-button{
      border-radius: 6px;
      font-family: "Lato";
      font-size: 1.6rem;
      height: 3.951rem;
      text-transform: none;
    }

    form.ui.form > div.field {
      margin: 2.24rem 0 !important;
    }
    .ui.form .field > label {
      display: block;
      margin: 0em 0em 0.28571429rem 0em;
    }
    .adminform{
      margin-top:30px;
    }
    .submit{
      width:83%;
      padding:12px;
      font-size:20px;
    }
    .current-insurence-input{
      width:24%;
      display:inline-block;
    }
	.img-icon-left{
		height: auto;
		height: 50px;
	}
	.img-icon-container{
		align-items: center;
		border: 1px solid #d6d6d6;
		border-radius: 3px;
		display: flex;
		height: 180px;
		margin-top: 2.24rem;
		padding: 2.24rem 1.143rem;
	}
	.img-icon-row{
		display: flex;
		justify-content: center;
		width: 30%;
	}
	
    </style>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
  
	 <?php require('sidebar.php'); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php require('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <div class="loader"></div>
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Add/Edit User</h1>
          
          <div class="card shadow mb-4" style="padding:20px">
            
			  <form class="adminform" name="adminform" action="" method="POST"> 
				<div class="form-group row">
				  <label for="name" class="col-sm-2">Name</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="name" name="name" aria-describedby="name" placeholder="Enter Name" value="<?php echo $enquiry['name'] ?>" >
				  </div>
				  <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
				</div>
				<div class="form-group row">
				  <label for="email" class="col-sm-2">Email</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="email"  name="email" aria-describedby="email" placeholder="Enter Email"  value="<?php echo $enquiry['email'] ?>">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="password" class="col-sm-2">Password</label>
				  <div class="col-sm-8">
					<input type="password" class="form-control" id="password"  name="password" aria-describedby="password" placeholder="Enter Password"  value="<?php echo $enquiry['password'] ?>">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="con_password" class="col-sm-2">Conform Password</label>
				  <div class="col-sm-8">
					<input type="password" class="form-control" id="con_password"  name="con_password" aria-describedby="con_password" placeholder="Conform Password"  value="<?php echo '' ?>">
				  </div>
				</div>
				
				<input type="hidden" name="id" value="<?php echo $id ?>">
				<input type="submit" name="submit" value="<?php echo ($id>0)?'Update':'Create'; ?>" class="btn btn-primary submit">
			  </form>
			
          </div>
        </div>
      </div>

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; jmat.my 2020</span>
            <div style="margin-top: 10px;">Developed By <a href="https://www.operion.com.my" target="_blank">Operion Web Creation Company</a></div>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
  
  <script>
  
  
  </script>

</body>

</html>
