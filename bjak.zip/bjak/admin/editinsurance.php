<?php
require('../connection.php');
$id = 0;
if(isset($_GET['id']) && !empty($_GET['id'])){
	$id = $_GET['id'];	
}
if(!empty($id)){
	$sql = "SELECT * FROM insurance WHERE id=".$id;
	$result = $conn->query($sql);
	if($result->num_rows > 0){
		$insurance = $result->fetch_assoc();
	}
}else{
	$insurance = array(
		"id"=>null,
		"logo"=>null,
		"insurance_company"=>null,
		"remarks"=>null
	);
}

if(isset($_POST['submit'])){
	$logo = '';
	if(!empty($_FILES)){
		$time = time();
		$filename = $_FILES['logo']['name']; 			
		$src = $_FILES['logo']['tmp_name'];
		
		if(!empty($_FILES['logo']['name'])){				
			$url='img/logo/'.$time.$filename;
			if(!move_uploaded_file($src, $url))	{
				return false;
			}
			$logo = $time.$filename;
		}
			
	}
	
	  $insurance_company = $_POST['insurance_company'];
	  $remarks = $_POST['remarks'];
	  
	  if(empty($id)){
		  // create new insurance
		  $sql = "INSERT INTO `insurance` (id, logo, insurance_company, remarks)
		  VALUES (null, '".$logo."', '".$insurance_company."', '".$remarks."')";
	  }else if(!empty($logo)){
		  // Update enquiry
		  $sql = "UPDATE insurance SET `logo`='".$logo."', `insurance_company`='".$insurance_company."', `remarks`='".$remarks."' WHERE id=".$id; 
	  }else{
		  $sql = "UPDATE insurance SET `insurance_company`='".$insurance_company."', `remarks`='".$remarks."' WHERE id=".$id;
	  }
	  
	  if ($conn->query($sql) === TRUE) {
		  if(empty($id)){
			echo "<script>alert('Insurance Created successfully');</script>";
			header('Location: insurance.php');
		  }else{	
			echo "<script>alert('Insurance Update successfully');</script>";
			header('Location: insurance.php');			
		  }
	  }
	  //echo "<pre>"; print_r($conn->error); die();
	  $conn->close();
	  echo "<meta http-equiv='refresh' content='0'>";
  
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Add/Edit Insurance</title>

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<style>
    .carousel-inner > .item > img,
    .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
    }
    .check-box-layout {
      display: inline-block;
      border: 1px solid #d6d6d6;
      border-radius: 3px;
      font-family: "Lato";
      font-size: 1.6rem;
      font-weight: 400;
      padding: 1.143rem;
      text-align: center;
      width: 48%;
    }
    .check-box-layout p{
      text-align: center;
      padding: 5px;
    }
    .check-right{
      float: right;
    }
    .button-full-width{
      width: 100%;
      padding: 15px;
      margin-top: 50px;
    }
    .button-green {
      background: #1db954;
      border: none;
      color: white;
      font-size: 2.24rem;
      font-weight: 900;
      height: auto;
      margin-top: 1.143rem;
      padding: 1.143rem 4.39rem;
      box-shadow: 3px 3px 2px rgba(102, 102, 102, 0.5);
      border-radius: 6px;
      font-family: "Lato";

    }
    .active{
      border: none;
      background-color: #290ce8;
      color: white;
      font-weight: 700;
    }
    .back-button{
      border-radius: 6px;
      font-family: "Lato";
      font-size: 1.6rem;
      height: 3.951rem;
      text-transform: none;
    }

    form.ui.form > div.field {
      margin: 2.24rem 0 !important;
    }
    .ui.form .field > label {
      display: block;
      margin: 0em 0em 0.28571429rem 0em;
    }
    .adminform{
      margin-top:30px;
    }
    .submit{
      width:83%;
      padding:12px;
      font-size:20px;
    }
    .current-insurence-input{
      width:24%;
      display:inline-block;
    }
	.img-icon-left{
		height: auto;
		height: 50px;
	}
	.img-icon-container{
		align-items: center;
		border: 1px solid #d6d6d6;
		border-radius: 3px;
		display: flex;
		height: 180px;
		margin-top: 2.24rem;
		padding: 2.24rem 1.143rem;
	}
	.img-icon-row{
		display: flex;
		justify-content: center;
		width: 30%;
	}
	
    </style>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
  
	 <?php require('sidebar.php'); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php require('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <div class="loader"></div>
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Add/Edit Insurance</h1>
          
          <div class="card shadow mb-4" style="padding:20px">
            
			  <form class="adminform" name="adminform" action="" method="POST" enctype="multipart/form-data"> 
				<div class="form-group row">
				  <label for="logo" class="col-sm-2">Logo</label>
				  <div class="col-sm-8">
					<div class="row">
						<div class="col-sm-8">
							<input type="file" class="form-control" id="logo" name="logo" aria-describedby="name" placeholder="Enter Name" value="<?php //echo $insurance['logo'] ?>" >
						</div>
						<div class="col-sm-4">
							<?php 
							if($insurance['logo']){
								echo '<img src="img/logo/'.$insurance['logo'].'" alt="'. $insurance['logo'].'" width="120" height="50px">';
							}
							?>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<label for="logo" class="col-sm-12">Note: The image must be in the width 120px X height 50px</label>
						</div>
					</div>
				  </div>
				  <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
				</div>
				<div class="form-group row">
				  <label for="insurance_company" class="col-sm-2">Insurance Company</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="insurance_company"  name="insurance_company" aria-describedby="insurance_company" placeholder="Enter Insurance Company"  value="<?php echo $insurance['insurance_company'] ?>">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="remarks" class="col-sm-2">Remarks</label>
				  <div class="col-sm-8">
					<textarea class="form-control" name="remarks"id="remarks" placeholder="Enter Remarks"> <?php echo $insurance['remarks'] ?> </textarea>
					
				  </div>
				</div>
				
				<input type="hidden" name="id" value="<?php echo $id ?>">
				<input type="submit" name="submit" value="<?php echo ($id>0)?'Update':'Create'; ?>" class="btn btn-primary submit">
			  </form>
			
          </div>
        </div>
      </div>

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; jmat.my 2020</span>
            <div style="margin-top: 10px;">Developed By <a href="https://www.operion.com.my" target="_blank">Operion Web Creation Company</a></div>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
  
  <script>
  
  
  </script>

</body>

</html>
