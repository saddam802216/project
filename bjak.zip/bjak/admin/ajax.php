<?php
	require('../connection.php');
	$data = $_POST;
	if(isset($data['task']) && $data['task']=='statusUpdate'){
		$obj = new stdClass();
		$obj->result = 'error';
		$sql = 'UPDATE car SET `status`="'.$data["status"].'" WHERE id='.$data["id"];
		if($conn->query($sql)){
			$obj->result = 'success';
		}
		exit(json_encode($obj));		
	}
	
	if(isset($data['task']) && $data['task']=='editEnquiry'){
		
		$obj = new stdClass();
		$obj->result = 'error';
		$sql = 'SELECT * FROM car WHERE id='.$data["id"];
		$result = $conn->query($sql);
		if($result->num_rows > 0){
			$enquiry = $result->fetch_assoc();
			
			$obj->result = 'success';
			
			// Insurence
			$insurences = array();
			$sql = "SELECT * FROM insurance";
			$result = $conn->query($sql);
			if($result->num_rows > 0){
				while($insurence = $result->fetch_assoc()) {
					$insurences[] = $insurence;			 
				}
			}
			if(!empty($insurences)){
				$insHtml = '';
				foreach($insurences as $insurence){
					$ins_selected = ($insurence['id']==$enquiry["insurence"])?"selected":"";
					$insHtml.= '<div class="col-sm-6">
						<input type="radio" name="insurence" id="insurence" value="'.$insurence['id'].'" '.$ins_selected.'>&nbsp;<lable>&nbsp;&nbsp;<img src="img/logo/'.$insurence["logo"].'" width="120px" height="50px"></lable>
					</div>';
				}
			}
			
			// create edit form
			$htmlForm = '';
			$htmlForm .= '<div class="container-fluid">
				<div class="loader"></div>
			  <!-- Page Heading -->
			  <!--<h1 class="h3 mb-2 text-gray-800">Add/Edit Enquiry</h1>-->
			  
			  <div class="card shadow mb-4" style="padding:20px">
				
				  <form class="editEnquiryForm" name="adminform" action="" method="POST"> 
					<div class="form-group row">
					  <label for="name" class="col-sm-2">Name</label>
					  <div class="col-sm-8">
						<input type="text" class="form-control" id="name" name="name" aria-describedby="name" placeholder="Enter Name" value="'. $enquiry["name"].'" >
					  </div>
					</div>
					<div class="form-group row">
					  <label for="ic" class="col-sm-2">IC</label>
					  <div class="col-sm-8">
						<input type="text" class="form-control" id="ic"  name="ic" aria-describedby="ic" placeholder="Enter IC"  value="'. $enquiry["ic"].'">
					  </div>
					</div>
					<div class="form-group row">
					  <label for="tel" class="col-sm-2">Tel</label>
					  <div class="col-sm-8">
						<input type="text" class="form-control" id="tel"  name="tel" aria-describedby="tel" placeholder="Enter Tel"  value="'.$enquiry["phone"].'">
					  </div>
					</div>
					<div class="form-group row">
					  <label for="email" class="col-sm-2">Email</label>
					  <div class="col-sm-8">
						<input type="text" class="form-control" id="email"  name="email" aria-describedby="email" placeholder="Enter Email"  value="'.$enquiry["email"].'">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="mailing_address" class="col-sm-2">Mailing Address</label>
					  <div class="col-sm-8">
						<input type="text" class="form-control" id="mailing_address"  name="email_to" aria-describedby="Mailing Address" placeholder="Enter Mailing Address"  value="'.$enquiry["email_to"].'">
					  </div>
					</div>

					<div class="form-group row">
					  <label for="vehicle" class="col-sm-2">Vehicle Number</label>
					  <div class="col-sm-8">
						<input type="text" class="form-control" id="vehicle"  name="vehicle" aria-describedby="vehicle" placeholder="Enter Vehicle Number"  value="'.$enquiry["vehicle"].'">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="current-insurence" class="col-sm-2">Current Insurance</label>
					  <div class="col-sm-8">
						<div class="row">'.$insHtml.'</div>
					  </div>  
					</div>
					<br><br>

					<div class="form-group row">
					  <label for="comprehensive" class="col-sm-6">1. Comprehensive/Third party</label>
					  <div class="col-sm-4">
						<input type="radio" class="" id="comprehensive"  name="comprehensive" value="1"';
						$selOption = ($enquiry["comprehensive"]==1)?"selected":"";
						$htmlForm .= $selOption.' >&nbsp;&nbsp;<label for="male">Comprehensive</label><br>
						<input type="radio" class="" id="third-party"  name="comprehensive" value="2"';
						$selOption = ($enquiry["comprehensive"]==2)?"selected":"";
						$htmlForm .= $selOption. ' >&nbsp;&nbsp;<label for="male">Third Party</label>
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="protection_amount" class="col-sm-6">2. Wind screen (protection amount) (RAM)</label>
					  <div class="col-sm-4">
						<input type="text" class="form-control" id="protection_amount"  name="protection_amount" aria-describedby="protection_amount" placeholder="" value="'.$enquiry["protection_amount"].'">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="road_tax" class="col-sm-6">3.Mailing Address To Receive Roadtax</label>
					  <div class="col-sm-4">
						<input type="text" class="form-control" id="road_tax"  name="road_tax" aria-describedby="road_tax" placeholder="" value="'.$enquiry["road_tax"]. '">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="driver_name" class="col-sm-6">4. Secondary deiver name/ IC</label>
					  <div class="col-sm-4">
						<input type="text" class="form-control" id="driver_name"  name="driver_name" aria-describedby="driver_name" placeholder="Name" value="'.$enquiry["driver_name"].'">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="ic_driver" class="col-sm-6">* Additional deiver to be insert in remark</label>
					  <div class="col-sm-4">
						<input type="text" class="form-control" id="ic_driver"  name="ic_driver" aria-describedby="ic_driver" placeholder="IC" value="'.$enquiry["ic_driver"] .'">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="remark" class="col-sm-6">5. Remark</label>
					  <div class="col-sm-4">
						<input type="text" class="form-control" id="remark"  name="remark" aria-describedby="remark" placeholder="" value="'.$enquiry["remark"].'">
					  </div>  
					</div>

					<div class="form-group row">
					  <label for="promo_code" class="col-sm-6">6. Promo Code</label>
					  <div class="col-sm-4">
						<input type="text" class="form-control" id="promo_code"  name="promo_code" aria-describedby="promo_code" placeholder="" value="'.$enquiry["promo_code"].'">
					  </div>  
					</div>
					<input type="hidden" name="id" value="'.$enquiry["id"].'">
					
					<input type="button" id="update-enquiry" name="submit" value="Update" class="btn btn-primary submit" javascript::void(0)>
				  </form>
				
			  </div>
			</div>';
			$obj->form = $htmlForm;
		}
		
		
		exit(json_encode($obj));		
	}
	
	
	if(isset($data['task']) && $data['task']=='updateEnquiry'){
		$obj = new stdClass();
		$obj->result = 'error';
		$formData = array();
		foreach($data["data"] as $key=>$value){
			//echo "<pre>"; print_r($value);
			$formData[$value["name"]] = $value["value"];
		}
// 		echo "<pre> data :"; print_r($data);
// 		echo "<pre> formData"; print_r($formData);
// 		die(__FILE__);
		if(isset($formData['id']) && !empty($formData['id'])){
			$insurence = (isset($formData['insurence']) && !empty($formData['insurence']))?$formData['insurence']:'';
			$comprehensive = (isset($formData['comprehensive']) && !empty($formData['comprehensive']))?$formData['comprehensive']:'';
			
			$sql = "UPDATE car SET `name`='".$formData['name']."', `ic`='".$formData['ic']."', `phone`='".$formData['tel']."', `email`='".$formData['email']."', `email_to`='".$formData['email_to']."', `vehicle`='".$formData['vehicle']."', `insurence`='".$insurence."', `comprehensive`='".$comprehensive."', `protection_amount`='".$formData['protection_amount']."', `road_tax`='".$formData['road_tax']."', `driver_name`='".$formData['driver_name']."', `ic_driver`='".$formData['ic_driver']."', `remark`='".$formData['remark']."', `promo_code`='".$formData['promo_code']."' WHERE `id`=".$formData['id']; 
			if($conn->query($sql)){
				$obj->result = 'success';
				mail($formData['email'], "Test Subject", "test message");
			}
			//print_r($conn->error);
		}
// 		die(__FILE__);
		exit(json_encode($obj));		
	}
	
	
?>