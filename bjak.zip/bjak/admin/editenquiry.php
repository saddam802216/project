<?php
require('../connection.php');
$id = 0;
if(isset($_GET['id']) && !empty($_GET['id'])){
	$id = $_GET['id'];	
}
if(!empty($id)){
	$sql = "SELECT * FROM car WHERE id=".$id;
	$result = $conn->query($sql);
	if($result->num_rows > 0){
		$enquiry = $result->fetch_assoc();
	}
}else{
	$enquiry = array(
		"id"=>null,
		"name"=>null,
		"ic"=>null,
		"phone"=>null,
		"email"=>null,
		"email_to"=>null,
		"vehicle"=>null,
		"ci1"=>null,
		"ci2"=>null,
		"ci3"=>null,
		"ci4"=>null,
		"ci5"=>null,
		"ci6"=>null,
		"ci7"=>null,
		"ci8"=>null,
		"comprehensive"=>null,
		"protection_amount"=>null,
		"road_tax"=>null,
		"driver_name"=>null,
		"ic_driver"=>null,
		"remark"=>null,
		"promo_code"=>null,
	);
}

if(isset($_POST['submit'])){
  $name = $_POST['name'];
  $ic = $_POST['ic'];
  $phone = $_POST['tel'];
  $email = $_POST['email'];
  $email_to = $_POST['email_to'];
  $vehicle = $_POST['vehicle'];
  $ci1 = $_POST['ci1'];
  $ci2 = $_POST['ci2'];
  $ci3 = $_POST['ci3'];
  $ci4 = $_POST['ci4'];
  $ci5 = $_POST['ci5'];
  $ci6 = $_POST['ci6'];
  $ci7 = $_POST['ci7'];
  $ci8 = $_POST['ci8'];
  $comprehensive = (isset($_POST['comprehensive']))?$_POST['comprehensive']:0;
  $protection_amount = $_POST['protection_amount'];
  $road_tax = $_POST['road_tax'];
  $driver_name = $_POST['driver_name'];
  $ic_driver = $_POST['ic_driver'];
  $remark = $_POST['remark'];
  $promo_code = $_POST['promo_code'];
  $created = date("Y-m-d");
  if(empty($id)){
	  // create new enquiry
	  $sql = "INSERT INTO `car` (id, name, ic, phone, email, email_to, vehicle, ci1, ci2, ci3, ci4, ci5, ci6, ci7, ci8, comprehensive, protection_amount, road_tax, driver_name, ic_driver, remark, promo_code, status, created)
	  VALUES (null, '".$name."', '".$ic."', '".$phone."', '".$email."', '".$email_to."', '".$vehicle."', '".$ci1."', '".$ci2."', '".$ci3."', '".$ci4."', '".$ci5."', '".$ci6."', '".$ci7."', '".$ci8."', '".$comprehensive."', '".$protection_amount."', '".$road_tax."', '".$driver_name."', '".$ic_driver."', '".$remark."', '".$promo_code."', '', '".$created."')";
  }else{
	  // Update enquiry
	  $sql = "UPDATE car SET `name`='".$name."', `ic`='".$ic."', `phone`='".$phone."', `email`='".$email."', `email_to`='".$email_to."', `vehicle`='".$vehicle."', `ci1`='".$ci1."', `ci2`='".$ci2."', `ci3`='".$ci3."', `ci4`='".$ci4."', `ci5`='".$ci5."', `ci6`='".$ci6."', `ci7`='".$ci7."', `ci8`='".$ci8."', `comprehensive`='".$comprehensive."', `protection_amount`='".$protection_amount."', `road_tax`='".$road_tax."', `driver_name`='".$driver_name."', `ic_driver`='".$ic_driver."', `remark`='".$remark."', `promo_code`='".$promo_code."' WHERE `id`=".$id; 
  }
  
  if ($conn->query($sql) === TRUE) {
	  if(empty($id)){
        echo "<script>alert('Enquiry Created successfully');</script>";
		header('Location: enquiry.php');
	  }else{	
		echo "<script>alert('Enquiry Update successfully');</script>";  
	  }
  }
  
  //echo "<pre>"; print_r($conn->error); die();
  $conn->close();
  echo "<meta http-equiv='refresh' content='0'>";
  
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Add/Edit Enquiry</title>

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<style>
    .carousel-inner > .item > img,
    .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
    }
    .check-box-layout {
      display: inline-block;
      border: 1px solid #d6d6d6;
      border-radius: 3px;
      font-family: "Lato";
      font-size: 1.6rem;
      font-weight: 400;
      padding: 1.143rem;
      text-align: center;
      width: 48%;
    }
    .check-box-layout p{
      text-align: center;
      padding: 5px;
    }
    .check-right{
      float: right;
    }
    .button-full-width{
      width: 100%;
      padding: 15px;
      margin-top: 50px;
    }
    .button-green {
      background: #1db954;
      border: none;
      color: white;
      font-size: 2.24rem;
      font-weight: 900;
      height: auto;
      margin-top: 1.143rem;
      padding: 1.143rem 4.39rem;
      box-shadow: 3px 3px 2px rgba(102, 102, 102, 0.5);
      border-radius: 6px;
      font-family: "Lato";

    }
    .active{
      border: none;
      background-color: #290ce8;
      color: white;
      font-weight: 700;
    }
    .back-button{
      border-radius: 6px;
      font-family: "Lato";
      font-size: 1.6rem;
      height: 3.951rem;
      text-transform: none;
    }

    form.ui.form > div.field {
      margin: 2.24rem 0 !important;
    }
    .ui.form .field > label {
      display: block;
      margin: 0em 0em 0.28571429rem 0em;
    }
    .adminform{
      margin-top:30px;
    }
    .submit{
      width:83%;
      padding:12px;
      font-size:20px;
    }
    .current-insurence-input{
      width:24%;
      display:inline-block;
    }
	.img-icon-left{
		height: auto;
		height: 50px;
	}
	.img-icon-container{
		align-items: center;
		border: 1px solid #d6d6d6;
		border-radius: 3px;
		display: flex;
		height: 180px;
		margin-top: 2.24rem;
		padding: 2.24rem 1.143rem;
	}
	.img-icon-row{
		display: flex;
		justify-content: center;
		width: 30%;
	}
	
    </style>
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">
  
	 <?php require('sidebar.php'); ?>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <?php require('topbar.php'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <div class="loader"></div>
          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Add/Edit Enquiry</h1>
          
          <div class="card shadow mb-4" style="padding:20px">
            
			  <form class="adminform" name="adminform" action="" method="POST"> 
				<div class="form-group row">
				  <label for="name" class="col-sm-2">Name</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="name" name="name" aria-describedby="name" placeholder="Enter Name" value="<?php echo $enquiry['name'] ?>" >
				  </div>
				  <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
				</div>
				<div class="form-group row">
				  <label for="ic" class="col-sm-2">IC</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="ic"  name="ic" aria-describedby="ic" placeholder="Enter IC"  value="<?php echo $enquiry['ic'] ?>">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="tel" class="col-sm-2">Tel</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="tel"  name="tel" aria-describedby="tel" placeholder="Enter Tel"  value="<?php echo $enquiry['phone'] ?>">
				  </div>
				</div>
				<div class="form-group row">
				  <label for="email" class="col-sm-2">Email</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="email"  name="email" aria-describedby="email" placeholder="Enter Email"  value="<?php echo $enquiry['email'] ?>">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="mailing_address" class="col-sm-2">Mailing Address</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="mailing_address"  name="email_to" aria-describedby="Mailing Address" placeholder="Enter Mailing Address"  value="<?php echo $enquiry['email_to'] ?>">
				  </div>
				</div>

				<div class="form-group row">
				  <label for="vehicle" class="col-sm-2">Vehicle Number</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control" id="vehicle"  name="vehicle" aria-describedby="vehicle" placeholder="Enter Vehicle Number"  value="<?php echo $enquiry['vehicle'] ?>">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="current-insurence" class="col-sm-2">Current Insurence</label>
				  <div class="col-sm-8">
					<input type="text" class="form-control current-insurence-input" id="great-eastem"  name="ci1" aria-describedby="great-eastem" placeholder="Great Eastem"  value="<?php echo $enquiry['ci1'] ?>">
					<input type="text" class="form-control current-insurence-input" id="aia"  name="ci2" aria-describedby="aia" placeholder="AIA"  value="<?php echo $enquiry['ci2'] ?>">
					<input type="text" class="form-control current-insurence-input" id="chubb"  name="ci3" aria-describedby="chubb" placeholder="CHUBB"  value="<?php echo $enquiry['ci3'] ?>">
					<input type="text" class="form-control current-insurence-input" id="yyy"  name="ci4" aria-describedby="yyy" placeholder="YYY"  value="<?php echo $enquiry['ci4'] ?>">
					<input type="text" class="form-control current-insurence-input" id="msig"  name="ci5" aria-describedby="msig" placeholder="MSIG"  value="<?php echo $enquiry['ci5'] ?>">
					<input type="text" class="form-control current-insurence-input" id="allance"  name="ci6" aria-describedby="allance" placeholder="ALLANCE"  value="<?php echo $enquiry['ci6'] ?>">
					<input type="text" class="form-control current-insurence-input" id="xxx"  name="ci7" aria-describedby="xxx" placeholder="XXX"  value="<?php echo $enquiry['ci7'] ?>">
					<input type="text" class="form-control current-insurence-input" id="zzz"  name="ci8" aria-describedby="zzz" placeholder="ZZZ"  value="<?php echo $enquiry['ci8'] ?>">
				  </div>  
				</div>
				<br><br>

				<div class="form-group row">
				  <label for="comprehensive" class="col-sm-6">1. Comprehensive/Third party</label>
				  <div class="col-sm-4">
					<input type="radio" class="" id="comprehensive"  name="comprehensive" value="1" <?php echo ($enquiry['comprehensive']==1)?' selected ':''; ?>><label for="male">Comprehensive</label>
					<input type="radio" class="" id="third-party"  name="comprehensive" value="2" <?php echo ($enquiry['comprehensive']==2)?' selected ':''; ?>><label for="male">Third Party</label>
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="protection_amount" class="col-sm-6">2. Wind screen (protection amount) (RAM)</label>
				  <div class="col-sm-4">
					<input type="text" class="form-control" id="protection_amount"  name="protection_amount" aria-describedby="protection_amount" placeholder="" value="<?php echo $enquiry['protection_amount'] ?> ">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="road_tax" class="col-sm-6">3.Mailing Address To Receive Roadtax</label>
				  <div class="col-sm-4">
					<input type="text" class="form-control" id="road_tax"  name="road_tax" aria-describedby="road_tax" placeholder="" value="<?php echo $enquiry['road_tax'] ?>">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="driver_name" class="col-sm-6">4. Secondary deiver name/ IC</label>
				  <div class="col-sm-4">
					<input type="text" class="form-control" id="driver_name"  name="driver_name" aria-describedby="driver_name" placeholder="Name" value="<?php echo $enquiry['driver_name'] ?>">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="ic_driver" class="col-sm-6">* Additional deiver to be insert in remark</label>
				  <div class="col-sm-4">
					<input type="text" class="form-control" id="ic_driver"  name="ic_driver" aria-describedby="ic_driver" placeholder="IC" value="<?php echo $enquiry['ic_driver'] ?>">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="remark" class="col-sm-6">5. Remark</label>
				  <div class="col-sm-4">
					<input type="text" class="form-control" id="remark"  name="remark" aria-describedby="remark" placeholder="" value="<?php echo $enquiry['remark'] ?>">
				  </div>  
				</div>

				<div class="form-group row">
				  <label for="promo_code" class="col-sm-6">6. Promo Code</label>
				  <div class="col-sm-4">
					<input type="text" class="form-control" id="promo_code"  name="promo_code" aria-describedby="promo_code" placeholder="" value="<?php echo $enquiry['promo_code'] ?>">
				  </div>  
				</div>
				<input type="hidden" name="id" value="<?php echo $id ?>">
				<input type="submit" name="submit" value="<?php echo ($id>0)?'Update':'Create'; ?>" class="btn btn-primary submit">
			  </form>
			
          </div>
        </div>
      </div>

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; jmat.my 2020</span>
            <div style="margin-top: 10px;">Developed By <a href="https://www.operion.com.my" target="_blank">Operion Web Creation Company</a></div>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
  
  <script>
  
  
  </script>

</body>

</html>
