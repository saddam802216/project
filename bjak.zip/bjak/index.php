<?php
error_reporting(0);
require('connection.php');
// Insurence
$insurences = array();
$sql = "SELECT * FROM insurance";
$result = $conn->query($sql);
if($result->num_rows > 0){
	while($insurence = $result->fetch_assoc()) {
		$insurences[] = $insurence;			 
	}
}
if(isset($_POST['submit'])){
  $name = $_POST['name'];
  $ic = $_POST['ic'];
  $phone = $_POST['tel'];
  $email = $_POST['email'];
  $email_to = $_POST['email_to'];
  $vehicle = $_POST['vehicle'];
  $insurence = (isset($_POST['insurence']))?$_POST['insurence']:0;
  $comprehensive = (isset($_POST['comprehensive']))?$_POST['comprehensive']:0;
  $protection_amount = $_POST['protection_amount'];
  $road_tax = $_POST['road_tax'];
  $driver_name = $_POST['driver_name'];
  $ic_driver = $_POST['ic_driver'];
  $remark = $_POST['remark'];
  $promo_code = $_POST['promo_code'];
  $created = date("Y-m-d");
  $sql = "INSERT INTO `car` (id, name, ic, phone, email, email_to, vehicle, insurence, comprehensive, protection_amount, road_tax, driver_name, ic_driver, remark, promo_code, status, create)
  VALUES (null, '".$name."', '".$ic."', '".$phone."', '".$email."', '".$email_to."', '".$vehicle."', '".$insurence."', '".$comprehensive."', '".$protection_amount."', '".$road_tax."', '".$driver_name."', '".$ic_driver."', '".$remark."', '".$promo_code."', '', '".$created."')";
  //print_r($sql); die(__FILE__);
  if ($conn->query($sql) === TRUE) {
      mail($email, "Test Subject", "test message");
      echo "<script>alert('Request sent successfully');</script>";
  } else {
      //echo "<script>alert('Request not sent, please try again'. $mysqli -> error);</script>";
  }
  $conn->close();
  echo "<meta http-equiv='refresh' content='0'>";
  // echo "<pre>"; print_r($_POST);
  // die(__FILE__);
}


  function sendEmail($email_to){
    require("mail/class.phpmailer.php");
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Host = "smtp.gmail.com";  /*SMTP server*/
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = "ssl";
    $mail->Port = 587;
    $mail->Username = "";  /*Username*/ // example@gmail.com
    $mail->Password = "";    /**Password**/
    
    $mail->From = "";    /*From address required*/ // example@gmail.com
    $mail->FromName = "Test from Info";
    $mail->AddAddress(""); // example@gmail.com
    //$mail->AddReplyTo("mail@mail.com");
    
    $mail->IsHTML(true);
    
    $mail->Subject = "Test message from server";
    $mail->Body = "Test Mail<b>in bold!</b>";
    //$mail->AltBody = "This is the body in plain text for non-HTML mail clients";
    if(!$mail->Send())
    {
    // echo "Message could not be sent. <p>";
    // echo "Mailer Error: " . $mail->ErrorInfo;
    // exit;
    }
    return true;
  }
  
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JMAT</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/one-page-wonder.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .main-container{
      width: 55%;
    }
    .carousel-inner > .item > img,
    .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
    }
    .check-box-layout {
      display: inline-block;
      border: 1px solid #d6d6d6;
      border-radius: 3px;
      font-family: "Lato";
      font-size: 1.6rem;
      font-weight: 400;
      padding: 1.143rem;
      text-align: center;
      width: 48%;
    }
    .check-box-layout p{
      text-align: center;
      padding: 5px;
    }
    .check-right{
      float: right;
    }
    .button-full-width{
      width: 100%;
      padding: 15px;
      margin-top: 50px;
    }
    .button-green {
      background: #1db954;
      border: none;
      color: white;
      font-size: 2.24rem;
      font-weight: 900;
      height: auto;
      margin-top: 1.143rem;
      padding: 1.143rem 4.39rem;
      box-shadow: 3px 3px 2px rgba(102, 102, 102, 0.5);
      border-radius: 6px;
      font-family: "Lato";

    }
    .active{
      border: none;
      background-color: #290ce8;
      color: white;
      font-weight: 700;
    }
    .back-button{
      border-radius: 6px;
      font-family: "Lato";
      font-size: 1.6rem;
      height: 3.951rem;
      text-transform: none;
    }

    form.ui.form > div.field {
      margin: 2.24rem 0 !important;
    }
    .ui.form .field > label {
      display: block;
      margin: 0em 0em 0.28571429rem 0em;
    }
    .adminform{
      margin-top:30px;
    }
    .submit{
      width:83%;
      padding:12px;
      font-size:20px;
    }
    .current-insurence-input{
      width:24%;
      display:inline-block;
    }
    .img-icon-left{
		height: auto;
		height: 50px;
	}
	.img-icon-container{
		align-items: center;
		border: 1px solid #d6d6d6;
		border-radius: 3px;
		display: flex;
		height: 180px;
		margin-top: 2.24rem;
		padding: 2.24rem 1.143rem;
	}
	.img-icon-row{
		display: flex;
		justify-content: center;
		width: 30%;
	}

  @media only screen and (max-width: 600px) {
    .main-container{
      width: 100%;
    }
  }
    </style>

    <script>
      
      $(document).ready(function(){
        $('.second-page').hide();
        $('#next-button').click(function(){
            $('.first-page').hide();
			$('.second-page').show();
			window.scrollTo(0,0);
// 			let isCar = $('.check-left').hasClass('active');
// 			if(isCar){
// 				$('.first-page').hide();
// 				$('.second-page').show();
// 				window.scrollTo(0,0);
// 			}else{
// 				alert("Please select car");
// 			}
        });
        $('#back-button').click(function(){
          $('.second-page').hide();
          $('.first-page').show();
        });
        
		
        $(document).on('click', '.check-box-layout', function(){
          $('.check-box-layout').removeClass('active');
          $(this).addClass('active');
        });
      });
    </script>

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
    <div class="row">
      <div class="col-sm-3 col-sm-offset-12">
        <a class="navbar-brand" href="index.php">
        <img src="img/logo/logo.png" alt="Logo" style="margin-top: -15px;">
        </a>
      </div>
      <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="#">Sign Up</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Log In</a>
          </li>
        </ul>
      </div> -->
    </div>
  </nav>

  <div class="container main-container">
    <div class="first-page">
      <header class="">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
        
          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox">
      
            <div class="item active">
              <img src="img/slider/slider1.jpeg" alt="slider" width="460" height="345">
            </div>
      
            <div class="item">
              <img src="img/slider/slider2.jpeg" alt="slider" width="460" height="345">
            </div>
          
            <div class="item">
              <img src="img/slider/slider3.jpeg" alt="slider" width="460" height="345">
            </div>
      
          </div>
        </div>
      </header>

      <section>
        <div class="">
          <div class="">
            <h1>A smarter way to renew motor insurance.</h1>
            <h1 style="color: red;">Compare and Save!</h1>
            <h3>Start here to get a FREE quote</h3>
            <p>What's your Vehicle Type?</p>
          </div>
        </div>
      </section>

      <section>
        <div class=''>
          <!--<div class="align-items-center">-->
          <!--  <div class="check-left check-box-layout">-->
          <!--    <p>The Car</p>-->
          <!--  </div>-->
          <!--  <div class="check-right check-box-layout">-->
          <!--    <p>Motorcycle</p>-->
          <!--  </div>-->
          <!--</div>-->
          <button class="button button-accented-bold button-green button-full-width" type="button" id="next-button">Proceed</button>
        </div>
      </section>
  <!--    <section>-->
		<!--<div class="" style="margin-top:100px;">-->
		<!--	<div class="col-sm-6" style="text-align: center">	-->
		<!--		<a href="#" target="_blank" rel="noopener noreferrer">-->
		<!--			<img width="160px" src="img/google-rating.png" class="wa-landing__ratings-img">-->
		<!--		</a>-->
		<!--	</div>-->
		<!--	<div class="col-sm-6" style="text-align: center">-->
		<!--		<a href="#" target="_blank" rel="noopener noreferrer">-->
		<!--			<img width="160px" src="img/fb-rating.png" class="wa-landing__ratings-img">-->
		<!--		</a>-->
		<!--	</div>-->
		<!--</div>-->
	 <!-- </section>-->
	  
	  <section>
		<div class="" style="margin-top:70px;">
			<h2 class="">Dengan Bjak,</h2>
			<h2 class="">anda akan dapat</h2>
			<div class="img-icon-container">
				<div class="img-icon-row">
					<img src="img/instant.svg" class="img-icon-left" >
				</div>
				<div class="img-content-row">
					<h4 class="">Insurans Active Segera</h4>
					<span class="">Baru bayar, sudah aktif</span>
				</div>
			</div>
			<div class="img-icon-container">
				<div class="img-icon-row">
					<img src="img/towing.svg" class="img-icon-left">
				</div>
				<div class="img-content-row">
					<h4 class="">PERCUMA Khidmat Tunda Tanpa Had</h4>
					<span class="">Khas untuk pelanggan Bjak</span>
				</div>
			</div>
			<div class="img-icon-container">
				<div class="img-icon-row">
					<img src="img/24hr.svg" class="img-icon-left">
				</div>
				<div class="img-content-row">
					<h4 class="">24 jam khidmat bantuan tuntutan</h4>
					<span class="">Jaminan Panggilan dijawab</span>
				</div>
			</div>
		</div>
	  </section>
    </div>


    <div class="second-page">
      <button class="back-button" id="back-button"><i aria-hidden="true" class="chevron left icon"></i>Back</button>
      <form class="adminform" name="adminform" action="" method="POST"> 
        <div class="form-group row">
          <label for="name" class="col-sm-2">Name</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="name" name="name" aria-describedby="name" placeholder="Enter Name">
          </div>
          <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
        </div>
        <div class="form-group row">
          <label for="ic" class="col-sm-2">IC</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="ic"  name="ic" aria-describedby="ic" placeholder="Enter IC">
          </div>
        </div>
        <div class="form-group row">
          <label for="tel" class="col-sm-2">Tel</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="tel"  name="tel" aria-describedby="tel" placeholder="Enter Tel">
          </div>
        </div>
        <div class="form-group row">
          <label for="email" class="col-sm-2">Email</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="email"  name="email" aria-describedby="email" placeholder="Enter Email">
          </div>  
        </div>

        <div class="form-group row">
          <label for="mailing_address" class="col-sm-2">Mailing Address</label>
          <div class="col-sm-8">
              <textarea class="form-control" id="mailing_address"  name="email_to" aria-describedby="Mailing Address" placeholder="Enter Mailing Address"></textarea>
            
          </div>
        </div>

        <div class="form-group row">
          <label for="vehicle" class="col-sm-2">Vehicle Number</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="vehicle"  name="vehicle" aria-describedby="vehicle" placeholder="Enter Vehicle Number">
          </div>  
        </div>

        <div class="form-group row">
          <label for="current-insurence" class="col-sm-2">Current Insurance</label>
          <div class="col-sm-8">
			<div class="row">
			<?php
			if(!empty($insurences)){
				foreach($insurences as $insurence){
					echo '<div class="col-sm-6">
						<input type="radio" name="insurence" id="insurence" value="'.$insurence['id'].'"><lable>&nbsp;&nbsp;<img src="admin/img/logo/'.$insurence["logo"].'" width="120px" height="50px"></lable>
					</div>';
				}
			}
				
			?>
				
			</div>
           
          </div>  
        </div>
        <br><br>

        <div class="form-group row">
          <label for="comprehensive" class="col-sm-6">1. Comprehensive/Third party</label>
          <div class="col-sm-4">
            <input type="radio" class="" id="comprehensive"  name="comprehensive" value="1"><label for="male"> &nbsp; Comprehensive</label><br>
            <input type="radio" class="" id="third-party"  name="comprehensive" value="2"><label for="male"> &nbsp; Third Party</label>
          </div>  
        </div>

        <div class="form-group row">
          <label for="protection_amount" class="col-sm-6">2. Wind screen (protection amount) (RAM)</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="protection_amount"  name="protection_amount" aria-describedby="protection_amount" placeholder="">
          </div>  
        </div>

        <div class="form-group row">
          <label for="road_tax" class="col-sm-6">3.Mailing Address To Receive Roadtax</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="road_tax"  name="road_tax" aria-describedby="road_tax" placeholder="">
          </div>  
        </div>

        <div class="form-group row">
          <label for="driver_name" class="col-sm-6">4. Secondary deiver name/ IC</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="driver_name"  name="driver_name" aria-describedby="driver_name" placeholder="Name">
          </div>  
        </div>

        <div class="form-group row">
          <label for="ic_driver" class="col-sm-6">* Additional deiver to be insert in remark</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="ic_driver"  name="ic_driver" aria-describedby="ic_driver" placeholder="IC">
          </div>  
        </div>

        <div class="form-group row">
          <label for="remark" class="col-sm-6">5. Remark</label>
          <div class="col-sm-4">
              <textarea class="form-control" id="remark"  name="remark" aria-describedby="remark" placeholder=""></textarea>
            <!--<input type="text" class="form-control" id="remark"  name="remark" aria-describedby="remark" placeholder="">-->
          </div>  
        </div>

        <div class="form-group row">
          <label for="promo_code" class="col-sm-6">6. Promo Code</label>
          <div class="col-sm-4">
            <input type="text" class="form-control" id="promo_code"  name="promo_code" aria-describedby="promo_code" placeholder="">
          </div>  
        </div>
 
        <input type="submit" name="submit" value="Submit" class="btn btn-primary Submit">
      </form>
    </div>
  </div>
  <!-- Footer -->
  <footer class="py-5 bg-black" style="margin-top:50px">
    <div class="container">
      <p class="m-0 text-center text-white small">Copyright &copy; Jmat.my 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
